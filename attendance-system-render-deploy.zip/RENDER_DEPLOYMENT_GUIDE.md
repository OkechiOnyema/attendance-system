# 🚀 Render Deployment Guide - Attendance System

> **Complete guide for deploying the restructured Attendance System to Render**

## 📋 **Prerequisites**

- ✅ **GitHub Repository** - System already deployed to GitHub
- ✅ **Render Account** - Free account at [render.com](https://render.com)
- ✅ **Python 3.11+** - Compatible with our system
- ✅ **PostgreSQL Database** - Will be created automatically on Render

## 🎯 **What We're Deploying**

### **System Components**
- **17 Normalized Database Models** - Complete academic structure
- **Professional Admin Interface** - Django admin for all models
- **Modern Frontend Templates** - Responsive Bootstrap UI
- **Authentication System** - User login/logout functionality
- **Sample Data** - Test accounts and course data

### **Technical Stack**
- **Backend**: Django 5.2.3
- **Database**: PostgreSQL (production) / SQLite (fallback)
- **Static Files**: WhiteNoise for production serving
- **WSGI Server**: Gunicorn
- **Environment**: Python 3.11

## 🚀 **Deployment Steps**

### **Step 1: Prepare Local System**

1. **Ensure all changes are committed to GitHub**
   ```bash
   git add .
   git commit -m "🚀 Prepare for Render deployment"
   git push origin master
   ```

2. **Run deployment preparation script**
   ```bash
   python deploy_to_render.py
   ```

3. **Verify deployment files are present**
   - ✅ `render.yaml` - Render configuration
   - ✅ `requirements.txt` - Python dependencies
   - ✅ `config/settings_production.py` - Production settings
   - ✅ `config/wsgi.py` - WSGI application

### **Step 2: Connect to Render**

1. **Visit [Render Dashboard](https://dashboard.render.com)**
2. **Click "New +" → "Web Service"**
3. **Connect your GitHub repository**
4. **Select the `attendance-system` repository**

### **Step 3: Configure Web Service**

1. **Service Configuration**
   - **Name**: `attendance-system`
   - **Environment**: `Python`
   - **Region**: Choose closest to your users
   - **Branch**: `master`
   - **Root Directory**: Leave empty (root)

2. **Build & Deploy Settings**
   - **Build Command**: `pip install -r requirements.txt && python manage.py collectstatic --noinput`
   - **Start Command**: `gunicorn config.wsgi:application --bind 0.0.0.0:$PORT`

3. **Environment Variables**
   - `PYTHON_VERSION`: `3.11.0`
   - `DEBUG`: `False`
   - `SECRET_KEY`: Generate automatically
   - `DATABASE_URL`: Will be set automatically
   - `AUTO_CREATE_DB`: `True`

### **Step 4: Create Database**

1. **Click "New +" → "PostgreSQL"**
2. **Configure Database**
   - **Name**: `attendance-db`
   - **Database**: `attendance_system`
   - **User**: Auto-generated
   - **Region**: Same as web service

3. **Connect Database to Web Service**
   - The `render.yaml` will automatically link them
   - Database URL will be injected as environment variable

### **Step 5: Deploy**

1. **Click "Create Web Service"**
2. **Wait for build to complete** (5-10 minutes)
3. **Check build logs** for any errors
4. **Verify deployment** at your Render URL

## 🔧 **Configuration Files**

### **render.yaml**
```yaml
services:
  - type: web
    name: attendance-system
    env: python
    plan: free
    buildCommand: |
      python --version
      pip install --upgrade pip
      pip install -r requirements.txt
      python manage.py collectstatic --noinput
    startCommand: gunicorn config.wsgi:application --bind 0.0.0.0:$PORT
    envVars:
      - key: PYTHON_VERSION
        value: 3.11.0
      - key: DEBUG
        value: False
      - key: SECRET_KEY
        generateValue: true
      - key: DATABASE_URL
        fromDatabase:
          name: attendance-db
          property: connectionString
      - key: AUTO_CREATE_DB
        value: True
      - key: ALLOWED_HOSTS
        value: .onrender.com
```

### **requirements.txt**
```
Django==5.2.3
requests==2.31.0
whitenoise==6.6.0
gunicorn==21.2.0
psycopg2-binary==2.9.9
python-decouple==3.8
dj-database-url==2.1.0
Pillow==11.3.0
django-cors-headers==4.3.1
```

## 🌐 **Post-Deployment**

### **Access Your Application**
- **Main URL**: `https://attendance-system-muqs.onrender.com`
- **Admin Interface**: `https://attendance-system-muqs.onrender.com/admin/`
- **Student Dashboard**: `https://attendance-system-muqs.onrender.com/student-dashboard/`
- **Lecturer Dashboard**: `https://attendance-system-muqs.onrender.com/lecturer-dashboard/`

### **Test Accounts**
| Role | Username | Password |
|------|----------|----------|
| **Admin** | `admin` | `admin123` |
| **Lecturer** | `lecturer1` | `password123` |
| **Student** | `student1` | `password123` |

### **Verify Functionality**
1. **Home page loads** ✅
2. **User login works** ✅
3. **Admin interface accessible** ✅
4. **Database connections working** ✅
5. **Static files serving** ✅

## 🚨 **Troubleshooting**

### **Common Issues**

1. **Build Failures**
   - Check Python version compatibility
   - Verify all dependencies in requirements.txt
   - Check for syntax errors in code

2. **Database Connection Issues**
   - Verify DATABASE_URL environment variable
   - Check PostgreSQL service status
   - Ensure database is created and linked

3. **Static Files Not Loading**
   - Verify collectstatic command in build
   - Check WhiteNoise configuration
   - Ensure STATIC_ROOT is set correctly

4. **500 Server Errors**
   - Check application logs in Render dashboard
   - Verify DEBUG is set to False
   - Check for missing environment variables

### **Debug Commands**

```bash
# Check build logs
# View in Render dashboard

# Check application logs
# View in Render dashboard

# Test database connection
python manage.py dbshell

# Verify static files
python manage.py collectstatic --dry-run
```

## 📊 **Performance & Scaling**

### **Free Tier Limitations**
- **Build Time**: 15 minutes max
- **Sleep After Inactivity**: 15 minutes
- **Database**: 1GB storage
- **Bandwidth**: 100GB/month

### **Upgrade Options**
- **Starter Plan**: $7/month - Always on, custom domains
- **Standard Plan**: $25/month - Better performance, more resources

## 🔒 **Security Considerations**

### **Production Security**
- ✅ `DEBUG = False`
- ✅ `SECRET_KEY` auto-generated
- ✅ HTTPS enforced by Render
- ✅ Database credentials secured
- ✅ Static files served securely

### **Environment Variables**
- Never commit sensitive data to Git
- Use Render's environment variable system
- Rotate secrets regularly
- Monitor access logs

## 📈 **Monitoring & Maintenance**

### **Render Dashboard Features**
- **Build History** - Track deployment success/failures
- **Logs** - Application and build logs
- **Metrics** - Performance monitoring
- **Alerts** - Set up notifications for issues

### **Regular Maintenance**
- **Update Dependencies** - Keep packages current
- **Monitor Logs** - Check for errors regularly
- **Database Backups** - Render provides automatic backups
- **Performance Monitoring** - Watch for slowdowns

## 🎉 **Success Checklist**

- ✅ **Repository connected** to Render
- ✅ **Web service created** and configured
- ✅ **Database created** and linked
- ✅ **Build completed** successfully
- ✅ **Application accessible** at Render URL
- ✅ **All functionality working** (login, admin, dashboards)
- ✅ **Static files loading** correctly
- ✅ **Database operations** working
- ✅ **Test accounts accessible**

## 🔗 **Useful Links**

- **Render Dashboard**: https://dashboard.render.com
- **Render Documentation**: https://render.com/docs
- **Django Deployment**: https://docs.djangoproject.com/en/5.2/howto/deployment/
- **GitHub Repository**: https://github.com/OkechiOnyema/attendance-system

---

## 🏆 **Deployment Complete!**

Your **completely restructured Attendance System** is now deployed to Render with:

- **Professional hosting** on Render's infrastructure
- **PostgreSQL database** for production use
- **Automatic HTTPS** and security
- **Scalable architecture** ready for growth
- **Modern deployment** practices

**Next Steps**: Begin Phase 5 development with your live production system! 🚀
