#!/usr/bin/env python
"""
Setup script to create sample data for the Attendance System
Run this after migrations to populate the database with test data
"""

import os
import sys
import django
from datetime import date, timedelta

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from django.contrib.auth.models import User
from admin_ui.models import (
    Department, AcademicSession, Semester, Course, UserProfile,
    Student, Lecturer, CourseAssignment, CourseEnrollment
)

def create_sample_data():
    """Create sample data for testing"""
    print("🚀 Creating sample data for Attendance System...")
    
    # Create Department
    dept, created = Department.objects.get_or_create(
        code='CS',
        defaults={
            'name': 'Computer Science',
            'description': 'Department of Computer Science'
        }
    )
    print(f"✅ Department: {dept.name}")
    
    # Create Academic Session
    session, created = AcademicSession.objects.get_or_create(
        name='2024/2025',
        defaults={
            'start_date': date(2024, 9, 1),
            'end_date': date(2025, 8, 31)
        }
    )
    print(f"✅ Academic Session: {session.name}")
    
    # Create Semesters
    semester1, created = Semester.objects.get_or_create(
        session=session,
        name='1st',
        defaults={
            'start_date': date(2024, 9, 1),
            'end_date': date(2025, 1, 31)
        }
    )
    semester2, created = Semester.objects.get_or_create(
        session=session,
        name='2nd',
        defaults={
            'start_date': date(2025, 2, 1),
            'end_date': date(2025, 6, 30)
        }
    )
    print(f"✅ Semesters: {semester1.name}, {semester2.name}")
    
    # Create Courses
    course1, created = Course.objects.get_or_create(
        code='CS101',
        defaults={
            'title': 'Introduction to Computer Science',
            'department': dept,
            'credit_units': 3
        }
    )
    course2, created = Course.objects.get_or_create(
        code='CS201',
        defaults={
            'title': 'Data Structures and Algorithms',
            'department': dept,
            'credit_units': 4
        }
    )
    print(f"✅ Courses: {course1.code}, {course2.code}")
    
    # Create Users and Profiles
    # Lecturer
    lecturer_user, created = User.objects.get_or_create(
        username='lecturer1',
        defaults={
            'first_name': 'John',
            'last_name': 'Smith',
            'email': 'john.smith@university.edu'
        }
    )
    if created:
        lecturer_user.set_password('password123')
        lecturer_user.save()
    
    lecturer_profile, created = UserProfile.objects.get_or_create(
        user=lecturer_user,
        defaults={
            'user_type': 'lecturer',
            'department': dept,
            'phone_number': '+1234567890'
        }
    )
    
    lecturer, created = Lecturer.objects.get_or_create(
        user_profile=lecturer_profile,
        defaults={
            'employee_id': 'L001',
            'qualification': 'Ph.D. Computer Science',
            'specialization': 'Software Engineering'
        }
    )
    print(f"✅ Lecturer: {lecturer.user_profile.user.get_full_name()}")
    
    # Student
    student_user, created = User.objects.get_or_create(
        username='student1',
        defaults={
            'first_name': 'Alice',
            'last_name': 'Johnson',
            'email': 'alice.johnson@university.edu'
        }
    )
    if created:
        student_user.set_password('password123')
        student_user.save()
    
    student_profile, created = UserProfile.objects.get_or_create(
        user=student_user,
        defaults={
            'user_type': 'student',
            'department': dept,
            'phone_number': '+0987654321'
        }
    )
    
    student, created = Student.objects.get_or_create(
        user_profile=student_profile,
        defaults={
            'matric_number': 'CS2024001',
            'level': '200',
            'admission_year': 2024
        }
    )
    print(f"✅ Student: {student.user_profile.user.get_full_name()}")
    
    # Create Course Assignments
    assignment1, created = CourseAssignment.objects.get_or_create(
        lecturer=lecturer,
        course=course1,
        session=session,
        semester=semester1
    )
    assignment2, created = CourseAssignment.objects.get_or_create(
        lecturer=lecturer,
        course=course2,
        session=session,
        semester=semester1
    )
    print(f"✅ Course Assignments: {assignment1.course.code}, {assignment2.course.code}")
    
    # Create Course Enrollments
    enrollment1, created = CourseEnrollment.objects.get_or_create(
        student=student,
        course=course1,
        session=session,
        semester=semester1
    )
    enrollment2, created = CourseEnrollment.objects.get_or_create(
        student=student,
        course=course2,
        session=session,
        semester=semester1
    )
    print(f"✅ Course Enrollments: {enrollment1.course.code}, {enrollment2.course.code}")
    
    print("\n🎉 Sample data created successfully!")
    print("\n📋 Test Accounts:")
    print(f"   Lecturer: {lecturer_user.username} / password123")
    print(f"   Student: {student_user.username} / password123")
    print(f"   Admin: admin / admin123")
    print("\n🌐 Access the system at: http://127.0.0.1:8000/")

if __name__ == '__main__':
    create_sample_data()
