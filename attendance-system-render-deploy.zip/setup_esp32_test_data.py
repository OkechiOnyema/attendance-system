#!/usr/bin/env python3
"""
Setup ESP32 Test Data

This script creates the necessary database objects for testing the ESP32 workflow:
1. Creates an ESP32Device
2. Creates a NetworkSession
3. Sets up test data

Usage: python setup_esp32_test_data.py
"""

import os
import sys
import django

# Add the project directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Set up Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from admin_ui.models import ESP32Device, NetworkSession, Course, User
from django.utils import timezone
from datetime import date

def create_esp32_device():
    """Create an ESP32 device for testing"""
    print("🔧 Creating ESP32 Device...")
    
    try:
        # Check if device already exists
        device = ESP32Device.objects.get(device_id='ESP32_Smart_001')
        print(f"✅ ESP32 Device already exists: {device}")
        return device
    except ESP32Device.DoesNotExist:
        # Create new ESP32 device
        device = ESP32Device.objects.create(
            device_id='ESP32_Smart_001',
            device_name='CS101_Smart_Attendance',
            ssid='ESP32_Attendance',
            password='esp32pass123',
            location='Computer Science Lab 1',
            is_active=True
        )
        print(f"✅ ESP32 Device created: {device}")
        return device

def create_network_session(esp32_device):
    """Create a network session for testing"""
    print("\n🌐 Creating Network Session...")
    
    try:
        # Get or create a course
        course, created = Course.objects.get_or_create(
            code='CS101',
            defaults={'title': 'Introduction to Computer Science'}
        )
        if created:
            print(f"✅ Course created: {course}")
        else:
            print(f"✅ Course found: {course}")
        
        # Get or create a lecturer user
        lecturer, created = User.objects.get_or_create(
            username='lecturer_test',
            defaults={
                'first_name': 'Test',
                'last_name': 'Lecturer',
                'email': 'lecturer@test.com',
                'is_staff': True
            }
        )
        if created:
            lecturer.set_password('testpass123')
            lecturer.save()
            print(f"✅ Lecturer created: {lecturer}")
        else:
            print(f"✅ Lecturer found: {lecturer}")
        
        # Check if network session already exists
        try:
            network_session = NetworkSession.objects.get(
                esp32_device=esp32_device,
                course=course,
                session='2024/2025',
                semester='1st Semester',
                date=date.today()
            )
            print(f"✅ Network Session already exists: {network_session}")
            return network_session
        except NetworkSession.DoesNotExist:
            # Create new network session
            network_session = NetworkSession.objects.create(
                esp32_device=esp32_device,
                course=course,
                lecturer=lecturer,
                session='2024/2025',
                semester='1st Semester',
                date=date.today(),
                start_time=timezone.now(),
                is_active=True
            )
            print(f"✅ Network Session created: {network_session}")
            return network_session
            
    except Exception as e:
        print(f"❌ Error creating network session: {e}")
        return None

def check_database_status():
    """Check the current database status"""
    print("\n📊 Database Status Check")
    print("-" * 40)
    
    # Check ESP32 Devices
    devices = ESP32Device.objects.all()
    print(f"ESP32 Devices: {devices.count()}")
    for device in devices:
        print(f"  - {device.device_id}: {device.device_name}")
    
    # Check Network Sessions
    sessions = NetworkSession.objects.all()
    print(f"Network Sessions: {sessions.count()}")
    for session in sessions:
        print(f"  - {session.course.code} ({session.session}) - Active: {session.is_active}")
    
    # Check Courses
    courses = Course.objects.all()
    print(f"Courses: {courses.count()}")
    for course in courses:
        print(f"  - {course.code}: {course.title}")
    
    # Check Users
    users = User.objects.filter(is_staff=True)
    print(f"Staff Users: {users.count()}")
    for user in users:
        print(f"  - {user.username}: {user.get_full_name()}")

def main():
    """Main setup function"""
    print("🚀 ESP32 Test Data Setup")
    print("=" * 50)
    print("This script sets up the necessary database objects for ESP32 testing.")
    print("=" * 50)
    
    try:
        # Create ESP32 device
        esp32_device = create_esp32_device()
        
        # Create network session
        network_session = create_network_session(esp32_device)
        
        # Check database status
        check_database_status()
        
        print("\n" + "=" * 50)
        print("🎯 Setup Summary")
        print("=" * 50)
        if esp32_device and network_session:
            print("✅ ESP32 test data setup completed successfully!")
            print("\n💡 Next steps:")
            print("   1. Restart your Django server")
            print("   2. Run test_api_endpoints.py to verify API access")
            print("   3. Test with your ESP32 device")
        else:
            print("❌ Setup failed. Check the error messages above.")
            
    except Exception as e:
        print(f"❌ Setup failed with error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
