#!/usr/bin/env python
"""
Render Deployment Script for Attendance System
This script helps prepare the system for Render deployment
"""

import os
import shutil
import subprocess
import sys
from pathlib import Path

def print_step(message):
    """Print a formatted step message"""
    print(f"\n{'='*60}")
    print(f"🚀 {message}")
    print(f"{'='*60}")

def run_command(command, description):
    """Run a shell command and handle errors"""
    print(f"\n📋 {description}")
    print(f"💻 Running: {command}")
    
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ Success: {result.stdout}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error: {e}")
        print(f"📝 Error output: {e.stderr}")
        return False

def check_requirements():
    """Check if all requirements are met"""
    print_step("Checking Requirements")
    
    # Check Python version
    python_version = sys.version_info
    if python_version.major < 3 or (python_version.major == 3 and python_version.minor < 11):
        print("❌ Python 3.11+ is required")
        return False
    
    print(f"✅ Python {python_version.major}.{python_version.minor}.{python_version.micro}")
    
    # Check if we're in the right directory
    if not Path("manage.py").exists():
        print("❌ manage.py not found. Please run this script from the project root.")
        return False
    
    print("✅ Project structure looks good")
    return True

def prepare_static_files():
    """Prepare static files for deployment"""
    print_step("Preparing Static Files")
    
    # Collect static files
    if not run_command("python manage.py collectstatic --noinput", "Collecting static files"):
        return False
    
    # Check if staticfiles directory was created
    staticfiles_dir = Path("staticfiles")
    if not staticfiles_dir.exists():
        print("❌ Static files directory not created")
        return False
    
    print("✅ Static files prepared successfully")
    return True

def run_migrations():
    """Run database migrations"""
    print_step("Running Database Migrations")
    
    if not run_command("python manage.py makemigrations admin_ui", "Creating migrations"):
        return False
    
    if not run_command("python manage.py migrate", "Applying migrations"):
        return False
    
    print("✅ Database migrations completed")
    return True

def create_sample_data():
    """Create sample data for testing"""
    print_step("Creating Sample Data")
    
    if not run_command("python setup_sample_data.py", "Creating sample data"):
        print("⚠️ Sample data creation failed, but continuing...")
    
    print("✅ Sample data setup completed")
    return True

def check_deployment_files():
    """Check if all deployment files are present"""
    print_step("Checking Deployment Files")
    
    required_files = [
        "render.yaml",
        "requirements.txt",
        "config/settings_production.py",
        "config/wsgi.py"
    ]
    
    missing_files = []
    for file_path in required_files:
        if not Path(file_path).exists():
            missing_files.append(file_path)
    
    if missing_files:
        print(f"❌ Missing deployment files: {missing_files}")
        return False
    
    print("✅ All deployment files are present")
    return True

def create_deployment_package():
    """Create a deployment package"""
    print_step("Creating Deployment Package")
    
    # Files to exclude from deployment
    exclude_patterns = [
        "__pycache__",
        "*.pyc",
        ".git",
        ".venv",
        "db.sqlite3",
        "*.log",
        "media",
        "staticfiles"
    ]
    
    package_name = "attendance-system-render-deploy.zip"
    
    # Remove existing package
    if Path(package_name).exists():
        Path(package_name).unlink()
    
    # Create deployment package
    if not run_command(f"git archive --format=zip --output={package_name} HEAD", "Creating deployment package"):
        return False
    
    print(f"✅ Deployment package created: {package_name}")
    return True

def main():
    """Main deployment preparation function"""
    print("🎓 Attendance System - Render Deployment Preparation")
    print("=" * 60)
    
    # Check requirements
    if not check_requirements():
        print("\n❌ Requirements check failed. Please fix the issues and try again.")
        return False
    
    # Check deployment files
    if not check_deployment_files():
        print("\n❌ Deployment files check failed. Please ensure all files are present.")
        return False
    
    # Run migrations
    if not run_migrations():
        print("\n❌ Database migration failed.")
        return False
    
    # Create sample data
    create_sample_data()
    
    # Prepare static files
    if not prepare_static_files():
        print("\n❌ Static files preparation failed.")
        return False
    
    # Create deployment package
    if not create_deployment_package():
        print("\n❌ Deployment package creation failed.")
        return False
    
    print_step("🎉 DEPLOYMENT PREPARATION COMPLETE!")
    print("\n📋 Next Steps:")
    print("1. Push your changes to GitHub")
    print("2. Connect your GitHub repository to Render")
    print("3. Deploy using the render.yaml configuration")
    print("4. Your app will be available at: https://attendance-system-muqs.onrender.com")
    
    print("\n🔗 Render Dashboard: https://dashboard.render.com")
    print("📚 Documentation: https://render.com/docs")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
