from django.contrib import admin
# Student model is now managed in admin_ui admin.py
# from .models import Student
# admin.site.register(Student)
