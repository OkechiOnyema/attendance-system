#!/usr/bin/env python3
"""
Quick Database Check

This script quickly checks the database status to see what data exists.
Run this to understand why the ESP32 is getting "Failed to parse Django response".

Usage: python quick_db_check.py
"""

import os
import sys
import django

# Add the project directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Set up Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

def check_database():
    """Quick check of database status"""
    print("🔍 Quick Database Check")
    print("=" * 50)
    
    try:
        # Check NetworkSessions
        from admin_ui.models import NetworkSession
        sessions = NetworkSession.objects.all()
        print(f"📊 NetworkSessions: {sessions.count()}")
        
        if sessions.exists():
            for session in sessions:
                print(f"   - {session.course.code} ({session.session}) - Active: {session.is_active}")
        else:
            print("   ⚠️ No NetworkSessions found!")
        
        # Check ESP32Devices
        from admin_ui.models import ESP32Device
        devices = ESP32Device.objects.all()
        print(f"\n📱 ESP32Devices: {devices.count()}")
        
        if devices.exists():
            for device in devices:
                print(f"   - {device.device_id}: {device.device_name}")
        else:
            print("   ⚠️ No ESP32Devices found!")
        
        # Check Courses
        from admin_ui.models import Course
        courses = Course.objects.all()
        print(f"\n📚 Courses: {courses.count()}")
        
        if courses.exists():
            for course in courses[:5]:  # Show first 5
                print(f"   - {course.code}: {course.title}")
        else:
            print("   ⚠️ No Courses found!")
        
        # Check Users
        from django.contrib.auth.models import User
        users = User.objects.all()
        print(f"\n👥 Users: {users.count()}")
        
        superusers = User.objects.filter(is_superuser=True)
        print(f"   Superusers: {superusers.count()}")
        
        if superusers.exists():
            for user in superusers:
                print(f"     - {user.username} ({user.email})")
        
        # Check if there are any active sessions
        active_sessions = NetworkSession.objects.filter(is_active=True)
        print(f"\n🎯 Active NetworkSessions: {active_sessions.count()}")
        
        if active_sessions.exists():
            for session in active_sessions:
                print(f"   ✅ {session.course.code} - {session.session} - {session.date}")
        else:
            print("   ❌ No active NetworkSessions found!")
            print("   💡 This is why ESP32 gets 'No active session found'")
        
        return active_sessions.exists()
        
    except Exception as e:
        print(f"❌ Error checking database: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Main function"""
    print("🚀 Quick Database Status Check")
    print("=" * 50)
    
    has_active_sessions = check_database()
    
    print("\n" + "=" * 50)
    print("🎯 Summary")
    print("=" * 50)
    
    if has_active_sessions:
        print("✅ Active NetworkSessions found - ESP32 should work!")
        print("\n💡 Next steps:")
        print("   1. Test API endpoints: python debug_esp32_api.py")
        print("   2. Check ESP32 serial monitor")
    else:
        print("❌ No active NetworkSessions found!")
        print("\n🔧 To fix this:")
        print("   1. Create a superuser: python create_superuser.py")
        print("   2. Set up test data: python setup_esp32_test_data.py")
        print("   3. Or manually create NetworkSession in Django admin")

if __name__ == "__main__":
    main()
