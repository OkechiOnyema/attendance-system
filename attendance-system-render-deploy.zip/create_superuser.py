#!/usr/bin/env python3
"""
Create Superuser Account

This script creates a superuser account for accessing Django admin.
Run this if you don't have any superuser accounts.

Usage: python create_superuser.py
"""

import os
import sys
import django

# Add the project directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Set up Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from django.contrib.auth.models import User

def create_superuser():
    """Create a superuser account"""
    print("🔧 Creating Superuser Account")
    print("=" * 50)
    
    # Check if superuser already exists
    if User.objects.filter(is_superuser=True).exists():
        print("✅ Superuser already exists!")
        superusers = User.objects.filter(is_superuser=True)
        for user in superusers:
            print(f"   - {user.username} ({user.email})")
        return
    
    # Create superuser
    try:
        username = input("Enter username for superuser: ").strip()
        if not username:
            username = "admin"
            print(f"Using default username: {username}")
        
        email = input("Enter email for superuser: ").strip()
        if not email:
            email = "admin@example.com"
            print(f"Using default email: {email}")
        
        password = input("Enter password for superuser: ").strip()
        if not password:
            password = "admin123"
            print(f"Using default password: {password}")
        
        # Create the superuser
        superuser = User.objects.create_superuser(
            username=username,
            email=email,
            password=password
        )
        
        print(f"✅ Superuser created successfully!")
        print(f"   Username: {superuser.username}")
        print(f"   Email: {superuser.email}")
        print(f"   Is Superuser: {superuser.is_superuser}")
        print(f"   Is Staff: {superuser.is_staff}")
        
        print("\n💡 You can now:")
        print("   1. Login to Django admin at /admin/")
        print("   2. Login to your custom admin at /admin-panel/")
        print("   3. Manage all your models through the admin interface")
        
    except Exception as e:
        print(f"❌ Error creating superuser: {e}")
        import traceback
        traceback.print_exc()

def main():
    """Main function"""
    print("🚀 Superuser Account Creation")
    print("=" * 50)
    print("This script creates a superuser account for Django admin access.")
    print("=" * 50)
    
    create_superuser()
    
    print("\n" + "=" * 50)
    print("🎯 Next Steps")
    print("=" * 50)
    print("1. Restart your Django server")
    print("2. Go to /admin/ and login with your superuser credentials")
    print("3. You should now see all your models in the admin interface")
    print("4. Run setup_esp32_test_data.py to create test data")

if __name__ == "__main__":
    main()
