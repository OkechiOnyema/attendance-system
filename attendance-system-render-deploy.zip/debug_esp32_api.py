#!/usr/bin/env python3
"""
Debug ESP32 API Endpoints

This script helps debug the ESP32 API by testing each endpoint
and showing the exact responses.

Usage: python debug_esp32_api.py
"""

import requests
import json

# Configuration
DJANGO_SERVER = "http://localhost:8000"  # Change to your Django server URL

def test_esp32_endpoints():
    """Test each ESP32 API endpoint and show detailed responses"""
    print("🔍 Debugging ESP32 API Endpoints")
    print("=" * 50)
    
    # Test 1: Heartbeat endpoint
    print("\n💓 Test 1: ESP32 Heartbeat")
    print("-" * 40)
    
    try:
        heartbeat_data = {
            "device_id": "ESP32_Smart_001",
            "device_name": "CS101_Smart_Attendance",
            "status": "online"
        }
        
        response = requests.post(
            f"{DJANGO_SERVER}/admin-panel/api/esp32/heartbeat/",
            json=heartbeat_data,
            headers={'Content-Type': 'application/json'}
        )
        
        print(f"Status Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")
        print(f"Response Body: {response.text}")
        
        if response.status_code == 200:
            try:
                data = response.json()
                print(f"✅ JSON Response: {json.dumps(data, indent=2)}")
            except json.JSONDecodeError as e:
                print(f"❌ JSON Decode Error: {e}")
        else:
            print(f"❌ Request failed with status {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Network Error: {e}")
    
    # Test 2: Active Course endpoint
    print("\n📚 Test 2: ESP32 Active Course")
    print("-" * 40)
    
    try:
        response = requests.get(f"{DJANGO_SERVER}/admin-panel/api/esp32/active-course/")
        
        print(f"Status Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")
        print(f"Response Body: {response.text}")
        
        if response.status_code == 200:
            try:
                data = response.json()
                print(f"✅ JSON Response: {json.dumps(data, indent=2)}")
                
                # Check if there's an active session
                if data.get('has_active_session'):
                    print("🎯 Active Session Found!")
                    print(f"   Course: {data.get('course_code')} - {data.get('course_name')}")
                    print(f"   Session: {data.get('session_id')}")
                    print(f"   Date: {data.get('date')}")
                else:
                    print("⚠️ No Active Session")
                    print(f"   Message: {data.get('message', 'No message')}")
                    
            except json.JSONDecodeError as e:
                print(f"❌ JSON Decode Error: {e}")
        else:
            print(f"❌ Request failed with status {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Network Error: {e}")
    
    # Test 3: Course List endpoint (if we have a session)
    print("\n📋 Test 3: ESP32 Course List")
    print("-" * 40)
    
    try:
        # Try with a sample session ID
        session_id = "2024/2025"
        response = requests.get(f"{DJANGO_SERVER}/admin-panel/api/esp32/course-list/{session_id}/")
        
        print(f"Status Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")
        print(f"Response Body: {response.text}")
        
        if response.status_code == 200:
            try:
                data = response.json()
                print(f"✅ JSON Response: {json.dumps(data, indent=2)}")
                
                if data.get('courses'):
                    print(f"📚 Found {len(data['courses'])} courses")
                    for course in data['courses']:
                        print(f"   - {course['code']}: {course['title']}")
                else:
                    print("⚠️ No courses found")
                    print(f"   Message: {data.get('message', 'No message')}")
                    
            except json.JSONDecodeError as e:
                print(f"❌ JSON Decode Error: {e}")
        else:
            print(f"❌ Request failed with status {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Network Error: {e}")
    
    # Test 4: Mark Attendance endpoint
    print("\n📝 Test 4: ESP32 Mark Attendance")
    print("-" * 40)
    
    try:
        attendance_data = {
            "matric_number": "2021/123456",
            "course_code": "CS101",
            "session_id": "2024/2025",
            "device_id": "ESP32_Smart_001"
        }
        
        response = requests.post(
            f"{DJANGO_SERVER}/admin-panel/api/esp32/mark-attendance/",
            json=attendance_data,
            headers={'Content-Type': 'application/json'}
        )
        
        print(f"Status Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")
        print(f"Response Body: {response.text}")
        
        if response.status_code == 200:
            try:
                data = response.json()
                print(f"✅ JSON Response: {json.dumps(data, indent=2)}")
                
                if data.get('success'):
                    print("✅ Attendance marked successfully!")
                else:
                    print("❌ Attendance marking failed")
                    print(f"   Error: {data.get('message', 'No message')}")
                    
            except json.JSONDecodeError as e:
                print(f"❌ JSON Decode Error: {e}")
        else:
            print(f"❌ Request failed with status {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Network Error: {e}")

def check_django_admin():
    """Check if Django admin is accessible"""
    print("\n⚙️ Test 5: Django Admin Access")
    print("-" * 40)
    
    try:
        response = requests.get(f"{DJANGO_SERVER}/admin/")
        print(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            print("✅ Django admin is accessible")
        elif response.status_code == 302:
            print("✅ Django admin is accessible (redirects to login)")
        else:
            print(f"❌ Django admin returned status {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Network Error: {e}")

def main():
    """Main function"""
    print("🔧 ESP32 API Debug Tool")
    print("=" * 50)
    print("This script tests each ESP32 API endpoint and shows detailed responses.")
    print("=" * 50)
    
    # Test all endpoints
    test_esp32_endpoints()
    check_django_admin()
    
    print("\n" + "=" * 50)
    print("🎯 Debug Summary")
    print("=" * 50)
    print("✅ Check the responses above for each endpoint")
    print("❌ Look for any error messages or unexpected response formats")
    print("\n💡 Common Issues:")
    print("   1. No active NetworkSession in database")
    print("   2. Response format mismatch")
    print("   3. Database connection issues")
    print("   4. Missing test data")

if __name__ == "__main__":
    main()
