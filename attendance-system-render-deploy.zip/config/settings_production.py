"""
Production settings for Render deployment
"""
import os
from pathlib import Path
from .settings import *

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False

# Production allowed hosts
ALLOWED_HOSTS = [
    'localhost', 
    '127.0.0.1',
    '.onrender.com',
    'attendance-system-muqs.onrender.com'
]

# Security settings for production
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True
X_FRAME_OPTIONS = 'DENY'
SECURE_HSTS_SECONDS = 31536000
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True

# Database configuration for production
DATABASE_URL = os.environ.get('DATABASE_URL')
if DATABASE_URL and 'postgresql' in DATABASE_URL:
    import dj_database_url
    DATABASES = {
        'default': dj_database_url.parse(DATABASE_URL)
    }
    print("✅ Using PostgreSQL database from DATABASE_URL")
else:
    # Fallback to SQLite for development
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / 'db.sqlite3',
        }
    }
    print("⚠️ Using SQLite database (fallback)")

# Static files configuration
STATIC_URL = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'

# Add whitenoise for static files
MIDDLEWARE.insert(1, 'whitenoise.middleware.WhiteNoiseMiddleware')
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'

# Media files
MEDIA_ROOT = BASE_DIR / 'media'
MEDIA_URL = '/media/'

# Logging configuration for production
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'INFO',
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
    },
}

# Auto-create database tables if they don't exist
if os.environ.get('AUTO_CREATE_DB', 'True') == 'True':
    print("🔧 Auto-creating database tables...")
    try:
        from django.core.management import execute_from_command_line
        import sys
        
        # Run migrations silently
        execute_from_command_line(['manage.py', 'migrate', '--noinput'])
        print("✅ Database tables created successfully!")
        
        # Create superuser if none exists
        from django.contrib.auth.models import User
        if not User.objects.exists():
            User.objects.create_superuser('admin', 'admin@example.com', 'admin123')
            print("✅ Superuser 'admin' created with password 'admin123'")
        else:
            print("ℹ️ Superuser already exists")
            
    except Exception as e:
        print(f"⚠️ Auto-creation failed: {e}")
        print("📝 You may need to run migrations manually")

# Authentication settings
LOGIN_URL = '/login/'
LOGIN_REDIRECT_URL = '/dashboard/'
SUPERUSER_PASSKEY = os.environ.get('SUPERUSER_PASSKEY', 'super123')
