from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    # 🎓 Main landing page
    path('', include('admin_ui.urls', namespace='admin_ui')),

    # 🛠 Django Admin
    path('admin/', admin.site.urls),

    # 📊 Attendance App
    path('attendance/', include('attendance.urls')),
]
