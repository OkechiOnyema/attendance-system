#!/usr/bin/env python3
"""
Database Status Check

This script checks the database status and identifies any issues.
Run this to debug database problems.

Usage: python check_database.py
"""

import os
import sys
import django

# Add the project directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Set up Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from django.db import connection
from django.core.management import execute_from_command_line
from django.apps import apps

def check_database_connection():
    """Check if database connection is working"""
    print("🔍 Checking Database Connection")
    print("-" * 40)
    
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            result = cursor.fetchone()
            if result and result[0] == 1:
                print("✅ Database connection successful")
                return True
            else:
                print("❌ Database connection failed")
                return False
    except Exception as e:
        print(f"❌ Database connection error: {e}")
        return False

def check_migrations():
    """Check migration status"""
    print("\n📋 Checking Migration Status")
    print("-" * 40)
    
    try:
        # Check if migrations are needed
        from django.core.management import call_command
        from io import StringIO
        
        out = StringIO()
        call_command('showmigrations', stdout=out)
        migrations_output = out.getvalue()
        
        print("📊 Migration Status:")
        print(migrations_output)
        
        # Check for unapplied migrations
        if "[X]" in migrations_output and "[ ]" in migrations_output:
            print("⚠️ Some migrations are not applied")
            return False
        elif "[X]" in migrations_output:
            print("✅ All migrations are applied")
            return True
        else:
            print("❌ No migrations found")
            return False
            
    except Exception as e:
        print(f"❌ Error checking migrations: {e}")
        return False

def check_models():
    """Check if models are properly registered"""
    print("\n🏗️ Checking Model Registration")
    print("-" * 40)
    
    try:
        # Get all installed apps
        installed_apps = apps.get_app_configs()
        print(f"📱 Installed Apps: {len(installed_apps)}")
        
        for app_config in installed_apps:
            print(f"   - {app_config.label}: {app_config.name}")
            
            # Check models in each app
            models = app_config.get_models()
            if models:
                print(f"     Models: {len(models)}")
                for model in models:
                    print(f"       - {model.__name__}")
            else:
                print("     Models: None")
        
        return True
        
    except Exception as e:
        print(f"❌ Error checking models: {e}")
        return False

def check_admin_registration():
    """Check if models are registered in admin"""
    print("\n⚙️ Checking Admin Registration")
    print("-" * 40)
    
    try:
        from django.contrib import admin
        from django.contrib.admin.sites import site
        
        registered_models = site._registry.keys()
        print(f"📝 Models registered in admin: {len(registered_models)}")
        
        for model in registered_models:
            print(f"   - {model._meta.app_label}.{model._meta.model_name}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error checking admin registration: {e}")
        return False

def check_specific_models():
    """Check specific models that should exist"""
    print("\n🎯 Checking Specific Models")
    print("-" * 40)
    
    try:
        from admin_ui.models import (
            Course, Student, ESP32Device, NetworkSession,
            AttendanceSession, AttendanceRecord
        )
        
        models_to_check = [
            (Course, "Course"),
            (Student, "Student"),
            (ESP32Device, "ESP32Device"),
            (NetworkSession, "NetworkSession"),
            (AttendanceSession, "AttendanceSession"),
            (AttendanceRecord, "AttendanceRecord")
        ]
        
        for model_class, model_name in models_to_check:
            try:
                count = model_class.objects.count()
                print(f"✅ {model_name}: {count} records")
            except Exception as e:
                print(f"❌ {model_name}: Error - {e}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error checking specific models: {e}")
        return False

def main():
    """Main function"""
    print("🔧 Database Status Check")
    print("=" * 50)
    print("This script checks your database status and identifies issues.")
    print("=" * 50)
    
    # Run all checks
    db_ok = check_database_connection()
    migrations_ok = check_migrations()
    models_ok = check_models()
    admin_ok = check_admin_registration()
    specific_ok = check_specific_models()
    
    print("\n" + "=" * 50)
    print("🎯 Check Summary")
    print("=" * 50)
    
    checks = [
        ("Database Connection", db_ok),
        ("Migrations", migrations_ok),
        ("Model Registration", models_ok),
        ("Admin Registration", admin_ok),
        ("Specific Models", specific_ok)
    ]
    
    all_passed = True
    for check_name, check_result in checks:
        status = "✅ PASS" if check_result else "❌ FAIL"
        print(f"{check_name}: {status}")
        if not check_result:
            all_passed = False
    
    print("\n" + "=" * 50)
    if all_passed:
        print("🎉 All checks passed! Your database is healthy.")
        print("\n💡 Next steps:")
        print("   1. Create a superuser: python create_superuser.py")
        print("   2. Set up test data: python setup_esp32_test_data.py")
        print("   3. Test API endpoints: python test_api_endpoints.py")
    else:
        print("⚠️ Some checks failed. Here's what to do:")
        print("\n🔧 Fix Database Issues:")
        if not db_ok:
            print("   - Check your database settings in config/settings.py")
            print("   - Ensure database server is running")
        if not migrations_ok:
            print("   - Run: python manage.py makemigrations")
            print("   - Run: python manage.py migrate")
        if not admin_ok:
            print("   - Check admin_ui/admin.py for proper model registration")
            print("   - Restart Django server after changes")

if __name__ == "__main__":
    main()
