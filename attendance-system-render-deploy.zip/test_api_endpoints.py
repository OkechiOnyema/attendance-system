#!/usr/bin/env python3
"""
Quick API Endpoint Test

This script tests if the Django API endpoints are accessible.
Run this to debug the "Not Found" error.

Usage: python test_api_endpoints.py
"""

import requests
import json

# Configuration
DJANGO_SERVER = "http://localhost:8000"  # Change to your Django server URL

def test_api_endpoints():
    """Test all ESP32 API endpoints"""
    print("🔍 Testing Django API Endpoints")
    print("=" * 50)
    
    # Test 1: Check if Django server is running
    print("\n📡 Test 1: Django Server Status")
    print("-" * 40)
    
    try:
        response = requests.get(f"{DJANGO_SERVER}/")
        print(f"✅ Django server is running (Status: {response.status_code})")
    except requests.exceptions.RequestException as e:
        print(f"❌ Django server is not accessible: {e}")
        return
    
    # Test 2: Check admin-panel access
    print("\n🔐 Test 2: Admin Panel Access")
    print("-" * 40)
    
    try:
        response = requests.get(f"{DJANGO_SERVER}/admin-panel/")
        print(f"✅ Admin panel accessible (Status: {response.status_code})")
    except requests.exceptions.RequestException as e:
        print(f"❌ Admin panel not accessible: {e}")
    
    # Test 3: Test ESP32 API endpoints
    print("\n🛰️ Test 3: ESP32 API Endpoints")
    print("-" * 40)
    
    endpoints = [
        "/admin-panel/api/esp32/heartbeat/",
        "/admin-panel/api/esp32/active-course/",
        "/admin-panel/api/esp32/mark-attendance/",
        "/admin-panel/api/esp32/course-list/2024%2F2025/"
    ]
    
    for endpoint in endpoints:
        try:
            if "heartbeat" in endpoint:
                # POST request for heartbeat
                data = {
                    "device_id": "ESP32_Smart_001",
                    "device_name": "CS101_Smart_Attendance",
                    "status": "online"
                }
                response = requests.post(f"{DJANGO_SERVER}{endpoint}", json=data)
            elif "mark-attendance" in endpoint:
                # POST request for attendance
                data = {
                    "matric_number": "2021/123456",
                    "course_code": "CS101",
                    "session_id": "2024/2025",
                    "device_id": "ESP32_Smart_001"
                }
                response = requests.post(f"{DJANGO_SERVER}{endpoint}", json=data)
            else:
                # GET request for other endpoints
                response = requests.get(f"{DJANGO_SERVER}{endpoint}")
            
            print(f"✅ {endpoint} - Status: {response.status_code}")
            if response.status_code != 200:
                print(f"   Response: {response.text[:100]}...")
                
        except requests.exceptions.RequestException as e:
            print(f"❌ {endpoint} - Error: {e}")
    
    # Test 4: Check Django admin
    print("\n⚙️ Test 4: Django Admin")
    print("-" * 40)
    
    try:
        response = requests.get(f"{DJANGO_SERVER}/admin/")
        print(f"✅ Django admin accessible (Status: {response.status_code})")
    except requests.exceptions.RequestException as e:
        print(f"❌ Django admin not accessible: {e}")

def main():
    """Main test function"""
    print("🔧 Django API Endpoint Test")
    print("=" * 50)
    print("This test checks if your Django server and API endpoints are working.")
    print("=" * 50)
    
    test_api_endpoints()
    
    print("\n" + "=" * 50)
    print("🎯 Test Summary")
    print("=" * 50)
    print("✅ If all endpoints return 200, your API is working correctly")
    print("❌ If you see 404 errors, check:")
    print("   1. Django server is running")
    print("   2. URLs are configured correctly")
    print("   3. Server was restarted after URL changes")
    print("   4. No syntax errors in views.py")

if __name__ == "__main__":
    main()
