#!/usr/bin/env python3
"""
Test New ESP32 Workflow

This script tests the new ESP32 workflow:
1. Lecturer creates hotspot → ESP32 connects to it
2. Lecturer creates session → ESP32 receives session details
3. Students connect to ESP32 → See active courses from that session

Usage: python test_new_esp32_workflow.py
"""

import requests
import json
from datetime import datetime, timedelta

# Configuration
DJANGO_SERVER = "http://localhost:8000"  # Change to your Django server URL
ADMIN_PANEL = f"{DJANGO_SERVER}/admin-panel"

def test_esp32_workflow():
    """Test the complete ESP32 workflow"""
    print("🚀 Testing New ESP32 Workflow")
    print("=" * 50)
    
    # Test 1: Check if ESP32 can get active session info
    print("\n📡 Test 1: ESP32 Getting Active Session Info")
    print("-" * 40)
    
    try:
        response = requests.get(f"{ADMIN_PANEL}/api/esp32/active-course/")
        if response.status_code == 200:
            data = response.json()
            if data.get('has_active_session'):
                print("✅ Active session found!")
                print(f"   Course: {data['course_code']} - {data['course_name']}")
                print(f"   Session: {data['session_id']}")
                print(f"   Semester: {data['semester']}")
                print(f"   Date: {data['date']}")
                print(f"   Lecturer: {data['lecturer_name']}")
                
                # Test 2: Get course list for this session
                print("\n📚 Test 2: ESP32 Getting Course List")
                print("-" * 40)
                
                session_id = data['session_id']
                course_response = requests.get(f"{ADMIN_PANEL}/api/esp32/course-list/{session_id}/")
                
                if course_response.status_code == 200:
                    course_data = course_response.json()
                    if course_data.get('courses'):
                        print("✅ Course list retrieved successfully!")
                        print(f"   Total courses: {course_data['total_courses']}")
                        for course in course_data['courses']:
                            print(f"   - {course['code']}: {course['title']}")
                        
                        # Test 3: Mark attendance
                        print("\n📝 Test 3: ESP32 Marking Attendance")
                        print("-" * 40)
                        
                        # Test with a sample student (you'll need to adjust this)
                        test_attendance = {
                            "matric_number": "2021/123456",  # Change to actual student matric number
                            "course_code": data['course_code'],
                            "session_id": session_id,
                            "device_id": "ESP32_Smart_001",
                            "timestamp": int(datetime.now().timestamp() * 1000)
                        }
                        
                        attendance_response = requests.post(
                            f"{ADMIN_PANEL}/api/esp32/mark-attendance/",
                            json=test_attendance,
                            headers={'Content-Type': 'application/json'}
                        )
                        
                        if attendance_response.status_code == 200:
                            attendance_data = attendance_response.json()
                            if attendance_data.get('success'):
                                print("✅ Attendance marked successfully!")
                                print(f"   Student: {attendance_data['student_name']}")
                                print(f"   Course: {attendance_data['course_code']}")
                                print(f"   Status: {attendance_data['status']}")
                            else:
                                print("❌ Attendance marking failed:")
                                print(f"   Error: {attendance_data.get('message', 'Unknown error')}")
                        else:
                            print(f"❌ Attendance API request failed: {attendance_response.status_code}")
                            print(f"   Response: {attendance_response.text}")
                    else:
                        print("⚠️ No courses found in this session")
                        print(f"   Message: {course_data.get('message', 'No message')}")
                else:
                    print(f"❌ Course list API request failed: {course_response.status_code}")
                    print(f"   Response: {course_response.text}")
            else:
                print("⚠️ No active session found")
                print(f"   Message: {data.get('message', 'No message')}")
                print("\n💡 To test this workflow:")
                print("   1. Create a NetworkSession in Django admin")
                print("   2. Set it as active")
                print("   3. Run this test again")
        else:
            print(f"❌ Active course API request failed: {response.status_code}")
            print(f"   Response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Network error: {e}")
    except json.JSONDecodeError as e:
        print(f"❌ JSON parsing error: {e}")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")

def test_esp32_heartbeat():
    """Test ESP32 heartbeat functionality"""
    print("\n💓 Test 4: ESP32 Heartbeat")
    print("-" * 40)
    
    try:
        heartbeat_data = {
            "device_id": "ESP32_Smart_001",
            "device_name": "CS101_Smart_Attendance",
            "status": "online",
            "has_active_session": True
        }
        
        response = requests.post(
            f"{ADMIN_PANEL}/api/esp32/heartbeat/",
            json=heartbeat_data,
            headers={'Content-Type': 'application/json'}
        )
        
        if response.status_code == 200:
            data = response.json()
            if data.get('status') == 'success':
                print("✅ Heartbeat sent successfully!")
                print(f"   Response: {data.get('message', 'No message')}")
            else:
                print("⚠️ Heartbeat response indicates issue:")
                print(f"   Status: {data.get('status')}")
                print(f"   Message: {data.get('message', 'No message')}")
        else:
            print(f"❌ Heartbeat API request failed: {response.status_code}")
            print(f"   Response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Network error: {e}")
    except json.JSONDecodeError as e:
        print(f"❌ JSON parsing error: {e}")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")

def main():
    """Main test function"""
    print("🔧 New ESP32 Workflow Test Suite")
    print("=" * 50)
    print("This test verifies the new ESP32 workflow:")
    print("1. Lecturer hotspot → ESP32 connection")
    print("2. Session creation → ESP32 session holding")
    print("3. Student connection → Active course display")
    print("=" * 50)
    
    # Run tests
    test_esp32_workflow()
    test_esp32_heartbeat()
    
    print("\n" + "=" * 50)
    print("🎯 Test Summary")
    print("=" * 50)
    print("✅ If all tests passed, your new ESP32 workflow is working!")
    print("❌ Check the error messages above for any issues")
    print("\n💡 Next steps:")
    print("   1. Upload the updated ESP32 code to your device")
    print("   2. Configure ESP32 to connect to lecturer's hotspot")
    print("   3. Create a NetworkSession in Django admin")
    print("   4. Test with real students connecting to ESP32")

if __name__ == "__main__":
    main()
