#!/usr/bin/env python
"""
Test script to debug the ESP32 API endpoint and network sessions
"""

import requests
import json

def test_active_course_api():
    """Test the active course API endpoint"""
    print("🔍 Testing ESP32 Active Course API...")
    print("=" * 50)
    
    # Test the endpoint
    url = "http://localhost:8000/admin-panel/api/esp32/active-course/"
    
    try:
        # Test GET request (what ESP32 is sending)
        print("📤 Testing GET request...")
        response = requests.get(url)
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        
        if response.status_code == 200:
            data = response.json()
            print("\n📊 Parsed Response:")
            print(f"  has_active_session: {data.get('has_active_session')}")
            print(f"  course_code: {data.get('course_code')}")
            print(f"  course_name: {data.get('course_name')}")
            print(f"  session_id: {data.get('session_id')}")
        
        print("\n" + "=" * 50)
        
        # Test POST request (alternative method)
        print("📤 Testing POST request...")
        post_data = {"base_device_id": "ESP32_"}
        response = requests.post(url, json=post_data)
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        
    except Exception as e:
        print(f"❌ Error: {e}")

def test_network_sessions():
    """Test the network sessions directly"""
    print("\n🌐 Testing Network Sessions...")
    print("=" * 50)
    
    url = "http://localhost:8000/admin-panel/api/esp32/active-course/"
    
    try:
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            print(f"API Response: {json.dumps(data, indent=2)}")
        else:
            print(f"API Error: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    test_active_course_api()
    test_network_sessions()
