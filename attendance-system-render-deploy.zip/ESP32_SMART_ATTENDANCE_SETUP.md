# 🚀 ESP32 Smart Attendance System - Setup Guide

## 📋 **Overview**
This system creates a secure attendance marking environment where:
- **ESP32 connects to your laptop hotspot** for internet access
- **ESP32 creates its own WiFi network** for students (NO internet access)
- **Students must connect to ESP32** to mark attendance (physical presence authentication)
- **Active course sessions are fetched** from your Django server
- **Enrollment validation** ensures only enrolled students can mark attendance

## 🔧 **Hardware Requirements**
- ESP32 development board
- USB cable for programming
- Laptop with mobile hotspot capability

## 📱 **Network Configuration**
- **Laptop Hotspot SSID:** `AttendanceWiFi`
- **Laptop Hotspot Password:** `attendance123`
- **ESP32 Network SSID:** `ESP32_Attendance`
- **ESP32 Network Password:** `esp32pass123`
- **ESP32 IP Address:** `192.168.5.1`

## 🚀 **Step-by-Step Setup**

### **Step 1: Prepare Your Laptop Hotspot**
1. **Enable Mobile Hotspot** on your laptop
2. **Set SSID to:** `AttendanceWiFi`
3. **Set Password to:** `attendance123`
4. **Ensure internet access** is working on your laptop

### **Step 2: Upload ESP32 Code**
1. **Open Arduino IDE**
2. **Install ESP32 board support** if not already installed
3. **Install required libraries:**
   - `WiFi` (built-in)
   - `WebServer` (built-in)
   - `HTTPClient` (built-in)
   - `ArduinoJson` (install from Library Manager)
   - `DNSServer` (built-in)
4. **Open the file:** `esp32_smart_attendance.ino`
5. **Select your ESP32 board** and correct COM port
6. **Click Upload** and wait for completion

### **Step 3: Monitor ESP32 Startup**
1. **Open Serial Monitor** (Tools → Serial Monitor)
2. **Set baud rate to:** `115200`
3. **Power on/reset ESP32**
4. **Watch for these messages:**
   ```
   🚀 ESP32 Smart Attendance System Starting...
   📶 Connecting to laptop hotspot...
   ✅ Connected to laptop hotspot!
   📶 Hotspot IP: [your laptop's IP]
   🌐 Setting up ESP32 WiFi network...
   ✅ ESP32 WiFi Network Started Successfully!
   📶 SSID: ESP32_Attendance
   🔑 Password: esp32pass123
   🌐 IP Address: 192.168.5.1
   🌐 Web server started on port 80
   🔒 DNS server started (captive portal)
   ✅ ESP32 Smart Attendance System Ready!
   📱 Students can now connect to ESP32_Attendance network
   ```

### **Step 4: Test Active Course Detection**
1. **Wait for ESP32 to check active courses** (every 60 seconds)
2. **Look for this message in Serial Monitor:**
   ```
   🔍 Checking for active courses...
   📥 Django response: {"has_active_session":true,"course_code":"CSC101",...}
   ✅ Active course detected!
   📚 Course Code: CSC101
   📖 Course Name: Introduction to Computer Science
   🆔 Session ID: 2024/2025
   ```

## 📱 **Student Testing**

### **Step 1: Connect Student Device to ESP32**
1. **On student's phone/laptop:**
   - Go to WiFi settings
   - Connect to `ESP32_Attendance` network
   - Enter password: `esp32pass123`
2. **Note:** Device will have NO internet access (this is intentional for security)

### **Step 2: Access Attendance Form**
1. **Open web browser** on student device
2. **Navigate to:** `http://192.168.5.1`
3. **You should see:**
   - Smart Attendance header
   - Active course information (CSC101)
   - Attendance form with matric number field
   - "Mark Attendance" button

### **Step 3: Mark Attendance**
1. **Enter a valid matric number** (must be enrolled in CSC101)
2. **Click "Mark Attendance"**
3. **Check Serial Monitor** for:
   ```
   📝 Received attendance request: {"matric_number":"12345"}
   📤 Sending attendance with validation to Django: {...}
   📥 Django response: {"success":true,"message":"Attendance recorded..."}
   ```

## 🔍 **Troubleshooting**

### **Issue: ESP32 Can't Connect to Hotspot**
**Symptoms:**
- `❌ Failed to connect to laptop hotspot!`
- `⚠️ ESP32 will work in local mode only`

**Solutions:**
1. **Check laptop hotspot is enabled**
2. **Verify SSID and password match exactly**
3. **Ensure laptop has internet access**
4. **Check if laptop firewall is blocking ESP32**

### **Issue: No Active Courses Detected**
**Symptoms:**
- `⚠️ No active course session found`
- Attendance form shows "No Active Course Session"

**Solutions:**
1. **Run the database check script:** `python check_database.py`
2. **Ensure NetworkSession exists** with `is_active=True`
3. **Check Django server is accessible** from ESP32
4. **Verify ESP32 can reach:** `https://attendance-system-muqs.onrender.com`

### **Issue: Students Can't Access Form**
**Symptoms:**
- Students can't connect to ESP32 network
- Browser shows connection error

**Solutions:**
1. **Check ESP32 is powered on**
2. **Verify ESP32 network is running** (check Serial Monitor)
3. **Ensure correct SSID:** `ESP32_Attendance`
4. **Check password:** `esp32pass123`
5. **Try accessing:** `http://192.168.5.1`

### **Issue: Attendance Not Being Recorded**
**Symptoms:**
- Form submits but no success message
- Serial Monitor shows errors

**Solutions:**
1. **Check ESP32 internet connection** (hotspot)
2. **Verify Django server is running**
3. **Check student enrollment** in the course
4. **Review Django logs** for errors
5. **Ensure matric number format** is correct

## 📊 **Expected Serial Monitor Output**

### **Normal Operation:**
```
🚀 ESP32 Smart Attendance System Starting...
📶 Connecting to laptop hotspot...
✅ Connected to laptop hotspot!
📶 Hotspot IP: 192.168.137.192
🌐 Setting up ESP32 WiFi network...
✅ ESP32 WiFi Network Started Successfully!
📶 SSID: ESP32_Attendance
🔑 Password: esp32pass123
🌐 IP Address: 192.168.5.1
🌐 Web server started on port 80
🔒 DNS server started (captive portal)
✅ ESP32 Smart Attendance System Ready!
📱 Students can now connect to ESP32_Attendance network

💓 Sending heartbeat to Django...
✅ Heartbeat sent successfully!
📤 Django response: {"status":"ok"}

🔍 Checking for active courses...
📥 Django response: {"has_active_session":true,"course_code":"CSC101","course_name":"Introduction to Computer Science","session_id":"2024/2025"}
✅ Active course detected!
📚 Course Code: CSC101
📖 Course Name: Introduction to Computer Science
🆔 Session ID: 2024/2025

📝 Received attendance request: {"matric_number":"12345"}
📤 Sending attendance with validation to Django: {...}
📥 Django response: {"success":true,"message":"Attendance recorded for Student Name in CSC101"}
```

## 🎯 **Success Indicators**

✅ **ESP32 connects to laptop hotspot successfully**
✅ **ESP32 creates its own WiFi network**
✅ **Active course is detected from Django**
✅ **Students can connect to ESP32 network**
✅ **Attendance form loads with course information**
✅ **Attendance is recorded successfully**
✅ **Physical presence authentication works**

## 🔒 **Security Features**

- **Captive Portal:** All external requests redirected to ESP32
- **No Internet Access:** Students connected to ESP32 cannot access external sites
- **Physical Presence Required:** Must be connected to ESP32 to mark attendance
- **Enrollment Validation:** Only enrolled students can mark attendance
- **Network Verification:** Attendance records marked with `network_verified=True`

## 📞 **Support**

If you encounter issues:
1. **Check Serial Monitor** for error messages
2. **Run database diagnostic:** `python check_database.py`
3. **Verify network connectivity**
4. **Check Django server status**

---

**🎉 Congratulations! You now have a fully functional ESP32 Smart Attendance System!**
