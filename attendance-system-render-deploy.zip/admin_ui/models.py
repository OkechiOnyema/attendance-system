from django.db import models
from django.contrib.auth.models import User
from django.core.validators import RegexValidator

# ============================================================================
# CORE MODELS - Step 1: Basic Structure
# ============================================================================

class AcademicSession(models.Model):
    """Academic year/session (e.g., 2024/2025)"""
    name = models.CharField(max_length=20, unique=True, help_text="e.g., 2024/2025")
    start_date = models.DateField()
    end_date = models.DateField()
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.name
    
    class Meta:
        ordering = ['-name']
        verbose_name = "Academic Session"
        verbose_name_plural = "Academic Sessions"

class Semester(models.Model):
    """Semester within an academic session"""
    SEMESTER_CHOICES = [
        ('1st', '1st Semester'),
        ('2nd', '2nd Semester'),
        ('3rd', '3rd Semester'),
    ]
    
    session = models.ForeignKey(AcademicSession, on_delete=models.CASCADE)
    name = models.CharField(max_length=20, choices=SEMESTER_CHOICES)
    start_date = models.DateField()
    end_date = models.DateField()
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.session.name} - {self.get_name_display()}"
    
    class Meta:
        unique_together = ['session', 'name']
        ordering = ['session', 'name']

class Department(models.Model):
    """Academic department"""
    name = models.CharField(max_length=100, unique=True)
    code = models.CharField(max_length=10, unique=True, help_text="Short department code")
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.code} - {self.name}"
    
    class Meta:
        ordering = ['name']

class Course(models.Model):
    """Academic course"""
    code = models.CharField(max_length=20, unique=True, help_text="Course code (e.g., CS101)")
    title = models.CharField(max_length=200)
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    credit_units = models.PositiveIntegerField(default=3)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.code} - {self.title}"
    
    class Meta:
        ordering = ['code']

class UserProfile(models.Model):
    """Extended user profile for lecturers and students"""
    USER_TYPE_CHOICES = [
        ('lecturer', 'Lecturer'),
        ('student', 'Student'),
        ('registration_officer', 'Registration Officer'),
        ('admin', 'Administrator'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    user_type = models.CharField(max_length=20, choices=USER_TYPE_CHOICES)
    department = models.ForeignKey(Department, on_delete=models.CASCADE, null=True, blank=True)
    phone_number = models.CharField(max_length=15, blank=True)
    profile_picture = models.ImageField(upload_to='profile_pics/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.user.get_full_name()} ({self.get_user_type_display()})"
    
    class Meta:
        ordering = ['user__first_name', 'user__last_name']

class Student(models.Model):
    """Student information"""
    LEVEL_CHOICES = [
        ('100', '100 Level'),
        ('200', '200 Level'),
        ('300', '300 Level'),
        ('400', '400 Level'),
        ('500', '500 Level'),
    ]
    
    user_profile = models.OneToOneField(UserProfile, on_delete=models.CASCADE)
    matric_number = models.CharField(
        max_length=20, 
        unique=True,
        validators=[RegexValidator(r'^[A-Z0-9]+$', 'Only uppercase letters and numbers allowed')]
    )
    level = models.CharField(max_length=10, choices=LEVEL_CHOICES)
    admission_year = models.PositiveIntegerField()
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.matric_number} - {self.user_profile.user.get_full_name()}"
    
    class Meta:
        ordering = ['matric_number']

class Lecturer(models.Model):
    """Lecturer information"""
    user_profile = models.OneToOneField(UserProfile, on_delete=models.CASCADE)
    employee_id = models.CharField(max_length=20, unique=True)
    qualification = models.CharField(max_length=100, blank=True)
    specialization = models.CharField(max_length=200, blank=True)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.employee_id} - {self.user_profile.user.get_full_name()}"
    
    class Meta:
        ordering = ['user_profile__user__first_name']

class CourseAssignment(models.Model):
    """Assignment of courses to lecturers for specific sessions"""
    lecturer = models.ForeignKey(Lecturer, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    session = models.ForeignKey(AcademicSession, on_delete=models.CASCADE)
    semester = models.ForeignKey(Semester, on_delete=models.CASCADE)
    assigned_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.course.code} → {self.lecturer.user_profile.user.get_full_name()}"
    
    class Meta:
        unique_together = ['lecturer', 'course', 'session', 'semester']
        ordering = ['session', 'semester', 'course__code']

class CourseEnrollment(models.Model):
    """Student enrollment in courses"""
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    session = models.ForeignKey(AcademicSession, on_delete=models.CASCADE)
    semester = models.ForeignKey(Semester, on_delete=models.CASCADE)
    enrolled_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.student.matric_number} - {self.course.code}"
    
    class Meta:
        unique_together = ['student', 'course', 'session', 'semester']
        ordering = ['-enrolled_at']

# ============================================================================
# ATTENDANCE MODELS - Step 2: Attendance Tracking
# ============================================================================

class AttendanceSession(models.Model):
    """Attendance session for a specific course on a specific date"""
    course_assignment = models.ForeignKey(CourseAssignment, on_delete=models.CASCADE)
    date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField(null=True, blank=True)
    location = models.CharField(max_length=200, blank=True, help_text="Classroom location")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.course_assignment.course.code} - {self.date}"
    
    class Meta:
        unique_together = ['course_assignment', 'date']
        ordering = ['-date', 'course_assignment__course__code']

class AttendanceRecord(models.Model):
    """Individual student attendance record"""
    STATUS_CHOICES = [
        ('present', 'Present'),
        ('absent', 'Absent'),
        ('late', 'Late'),
        ('excused', 'Excused'),
    ]
    
    attendance_session = models.ForeignKey(AttendanceSession, on_delete=models.CASCADE)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='absent')
    marked_at = models.DateTimeField(auto_now_add=True)
    marked_by = models.ForeignKey(User, on_delete=models.CASCADE, help_text="User who marked this attendance")
    notes = models.TextField(blank=True, help_text="Additional notes or reasons")
    
    def __str__(self):
        return f"{self.student.matric_number} - {self.attendance_session.date}: {self.status}"
    
    class Meta:
        unique_together = ['attendance_session', 'student']
        ordering = ['-marked_at']

# ============================================================================
# ESP32 DEVICE MODELS - Step 3: Network-Based Attendance
# ============================================================================

class ESP32Device(models.Model):
    """ESP32 device for network-based attendance"""
    DEVICE_STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
        ('maintenance', 'Under Maintenance'),
        ('offline', 'Offline'),
    ]
    
    device_id = models.CharField(max_length=50, unique=True, help_text="Unique identifier for ESP32 device")
    device_name = models.CharField(max_length=100, help_text="Human-readable name")
    ssid_prefix = models.CharField(max_length=20, help_text="WiFi network name prefix")
    wifi_password = models.CharField(max_length=64, blank=True, help_text="WiFi password (if required)")
    location = models.CharField(max_length=200, help_text="Physical location")
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=DEVICE_STATUS_CHOICES, default='active')
    ip_address = models.GenericIPAddressField(blank=True, null=True)
    last_heartbeat = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.device_name} ({self.device_id})"
    
    class Meta:
        ordering = ['device_name']
        verbose_name = "ESP32 Device"
        verbose_name_plural = "ESP32 Devices"

class NetworkSession(models.Model):
    """Active network session for ESP32-based attendance"""
    esp32_device = models.ForeignKey(ESP32Device, on_delete=models.CASCADE)
    course_assignment = models.ForeignKey(CourseAssignment, on_delete=models.CASCADE)
    date = models.DateField()
    start_time = models.DateTimeField()
    end_time = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.course_assignment.course.code} - {self.date} ({self.esp32_device.ssid_prefix})"
    
    class Meta:
        unique_together = ['esp32_device', 'date']
        ordering = ['-date', '-start_time']

class ConnectedDevice(models.Model):
    """Device connected to ESP32 network during attendance"""
    network_session = models.ForeignKey(NetworkSession, on_delete=models.CASCADE)
    mac_address = models.CharField(max_length=17, help_text="Device MAC address")
    device_name = models.CharField(max_length=100, blank=True, null=True)
    ip_address = models.GenericIPAddressField(blank=True, null=True)
    connected_at = models.DateTimeField(auto_now_add=True)
    disconnected_at = models.DateTimeField(null=True, blank=True)
    is_connected = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.mac_address} - {self.network_session.course_assignment.course.code}"
    
    class Meta:
        unique_together = ['network_session', 'mac_address']
        ordering = ['-connected_at']

# ============================================================================
# FINGERPRINT MODELS - Step 4: Biometric Integration
# ============================================================================

class FingerprintEnrollment(models.Model):
    """Student fingerprint enrollment status"""
    ENROLLMENT_STATUS_CHOICES = [
        ('not_enrolled', 'Not Enrolled'),
        ('enrolled', 'Enrolled'),
        ('failed', 'Enrollment Failed'),
        ('expired', 'Enrollment Expired'),
    ]
    
    student = models.OneToOneField(Student, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=ENROLLMENT_STATUS_CHOICES, default='not_enrolled')
    fingerprint_data = models.TextField(blank=True, help_text="Encrypted fingerprint template data")
    enrolled_at = models.DateTimeField(null=True, blank=True)
    enrolled_by = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    last_used = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True, help_text="Enrollment notes or error messages")
    
    def __str__(self):
        return f"Fingerprint for {self.student.matric_number}"
    
    class Meta:
        verbose_name = "Fingerprint Enrollment"
        verbose_name_plural = "Fingerprint Enrollments"

# ============================================================================
# SYSTEM MODELS - Step 5: Logging and Configuration
# ============================================================================

class SystemLog(models.Model):
    """System activity logging"""
    LOG_LEVEL_CHOICES = [
        ('info', 'Information'),
        ('warning', 'Warning'),
        ('error', 'Error'),
        ('debug', 'Debug'),
    ]
    
    LOG_TYPE_CHOICES = [
        ('attendance', 'Attendance'),
        ('enrollment', 'Enrollment'),
        ('device', 'Device'),
        ('user', 'User'),
        ('system', 'System'),
    ]
    
    timestamp = models.DateTimeField(auto_now_add=True)
    level = models.CharField(max_length=10, choices=LOG_LEVEL_CHOICES)
    log_type = models.CharField(max_length=20, choices=LOG_TYPE_CHOICES)
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    message = models.TextField()
    details = models.JSONField(blank=True, null=True, help_text="Additional log details")
    
    def __str__(self):
        return f"{self.timestamp} - {self.level}: {self.message[:50]}"
    
    class Meta:
        ordering = ['-timestamp']
        verbose_name = "System Log"
        verbose_name_plural = "System Logs"

class SystemConfiguration(models.Model):
    """System configuration settings"""
    key = models.CharField(max_length=100, unique=True)
    value = models.TextField()
    description = models.TextField(blank=True)
    is_editable = models.BooleanField(default=True, help_text="Whether this setting can be changed via UI")
    updated_at = models.DateTimeField(auto_now=True)
    updated_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    
    def __str__(self):
        return f"{self.key}: {self.value[:50]}"
    
    class Meta:
        ordering = ['key']
        verbose_name = "System Configuration"
        verbose_name_plural = "System Configurations"
