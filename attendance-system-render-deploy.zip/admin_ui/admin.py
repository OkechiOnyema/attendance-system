from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe
from .models import (
    AcademicSession, Semester, Department, Course, UserProfile,
    Student, Lecturer, CourseAssignment, CourseEnrollment,
    AttendanceSession, AttendanceRecord, ESP32Device, NetworkSession,
    ConnectedDevice, FingerprintEnrollment, SystemLog, SystemConfiguration
)

# ============================================================================
# CORE MODELS ADMIN - Step 1: Academic Structure
# ============================================================================

@admin.register(AcademicSession)
class AcademicSessionAdmin(admin.ModelAdmin):
    list_display = ['name', 'start_date', 'end_date', 'is_active', 'created_at']
    list_filter = ['is_active', 'start_date', 'end_date']
    search_fields = ['name']
    ordering = ['-name']
    readonly_fields = ['created_at']
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'start_date', 'end_date', 'is_active')
        }),
        ('Timestamps', {
            'fields': ('created_at',),
            'classes': ('collapse',)
        }),
    )

@admin.register(Semester)
class SemesterAdmin(admin.ModelAdmin):
    list_display = ['name', 'session', 'start_date', 'end_date', 'is_active']
    list_filter = ['name', 'is_active', 'session']
    search_fields = ['session__name']
    ordering = ['session', 'name']
    
    fieldsets = (
        ('Semester Information', {
            'fields': ('session', 'name', 'start_date', 'end_date', 'is_active')
        }),
    )

@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ['code', 'name', 'is_active']
    list_filter = ['is_active']
    search_fields = ['code', 'name', 'description']
    ordering = ['name']
    
    fieldsets = (
        ('Department Information', {
            'fields': ('code', 'name', 'description', 'is_active')
        }),
    )

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ['code', 'title', 'department', 'credit_units', 'is_active']
    list_filter = ['is_active', 'department', 'credit_units']
    search_fields = ['code', 'title', 'department__name']
    ordering = ['code']
    readonly_fields = ['created_at']
    
    fieldsets = (
        ('Course Information', {
            'fields': ('code', 'title', 'department', 'credit_units', 'description', 'is_active')
        }),
        ('Timestamps', {
            'fields': ('created_at',),
            'classes': ('collapse',)
        }),
    )

# ============================================================================
# USER MODELS ADMIN - Step 2: User Management
# ============================================================================

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'user_type', 'department', 'phone_number', 'created_at']
    list_filter = ['user_type', 'department', 'created_at']
    search_fields = ['user__username', 'user__first_name', 'user__last_name', 'phone_number']
    ordering = ['user__first_name', 'user__last_name']
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('User Information', {
            'fields': ('user', 'user_type', 'department', 'phone_number', 'profile_picture')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ['matric_number', 'user_profile', 'level', 'admission_year', 'is_active']
    list_filter = ['level', 'admission_year', 'is_active', 'user_profile__department']
    search_fields = ['matric_number', 'user_profile__user__first_name', 'user_profile__user__last_name']
    ordering = ['matric_number']
    
    fieldsets = (
        ('Student Information', {
            'fields': ('user_profile', 'matric_number', 'level', 'admission_year', 'is_active')
        }),
    )

@admin.register(Lecturer)
class LecturerAdmin(admin.ModelAdmin):
    list_display = ['employee_id', 'user_profile', 'qualification', 'specialization', 'is_active']
    list_filter = ['is_active', 'user_profile__department']
    search_fields = ['employee_id', 'user_profile__user__first_name', 'user_profile__user__last_name']
    ordering = ['user_profile__user__first_name']
    
    fieldsets = (
        ('Lecturer Information', {
            'fields': ('user_profile', 'employee_id', 'qualification', 'specialization', 'is_active')
        }),
    )

# ============================================================================
# COURSE MANAGEMENT ADMIN - Step 3: Course Operations
# ============================================================================

@admin.register(CourseAssignment)
class CourseAssignmentAdmin(admin.ModelAdmin):
    list_display = ['course', 'lecturer', 'session', 'semester', 'assigned_at', 'is_active']
    list_filter = ['is_active', 'session', 'semester', 'course__department']
    search_fields = ['course__code', 'course__title', 'lecturer__user_profile__user__username']
    ordering = ['session', 'semester', 'course__code']
    readonly_fields = ['assigned_at']
    
    fieldsets = (
        ('Assignment Information', {
            'fields': ('lecturer', 'course', 'session', 'semester', 'is_active')
        }),
        ('Timestamps', {
            'fields': ('assigned_at',),
            'classes': ('collapse',)
        }),
    )

@admin.register(CourseEnrollment)
class CourseEnrollmentAdmin(admin.ModelAdmin):
    list_display = ['student', 'course', 'session', 'semester', 'enrolled_at', 'is_active']
    list_filter = ['is_active', 'session', 'semester', 'course__department']
    search_fields = ['student__matric_number', 'student__user_profile__user__first_name', 'course__code']
    ordering = ['-enrolled_at']
    readonly_fields = ['enrolled_at']
    
    fieldsets = (
        ('Enrollment Information', {
            'fields': ('student', 'course', 'session', 'semester', 'is_active')
        }),
        ('Timestamps', {
            'fields': ('enrolled_at',),
            'classes': ('collapse',)
        }),
    )

# ============================================================================
# ATTENDANCE ADMIN - Step 4: Attendance Management
# ============================================================================

@admin.register(AttendanceSession)
class AttendanceSessionAdmin(admin.ModelAdmin):
    list_display = ['course_assignment', 'date', 'start_time', 'end_time', 'location', 'is_active']
    list_filter = ['is_active', 'date', 'course_assignment__course__department']
    search_fields = ['course_assignment__course__code', 'location']
    ordering = ['-date', 'course_assignment__course__code']
    readonly_fields = ['created_at']
    
    fieldsets = (
        ('Session Information', {
            'fields': ('course_assignment', 'date', 'start_time', 'end_time', 'location', 'is_active')
        }),
        ('Timestamps', {
            'fields': ('created_at',),
            'classes': ('collapse',)
        }),
    )

@admin.register(AttendanceRecord)
class AttendanceRecordAdmin(admin.ModelAdmin):
    list_display = ['student', 'attendance_session', 'status', 'marked_at', 'marked_by']
    list_filter = ['status', 'marked_at', 'attendance_session__course_assignment__course__department']
    search_fields = ['student__matric_number', 'student__user_profile__user__first_name']
    ordering = ['-marked_at']
    readonly_fields = ['marked_at']
    
    fieldsets = (
        ('Attendance Information', {
            'fields': ('attendance_session', 'student', 'status', 'marked_by', 'notes')
        }),
        ('Timestamps', {
            'fields': ('marked_at',),
            'classes': ('collapse',)
        }),
    )

# ============================================================================
# ESP32 DEVICE ADMIN - Step 5: Device Management
# ============================================================================

@admin.register(ESP32Device)
class ESP32DeviceAdmin(admin.ModelAdmin):
    list_display = ['device_id', 'device_name', 'ssid_prefix', 'location', 'department', 'status', 'last_heartbeat']
    list_filter = ['status', 'department', 'created_at']
    search_fields = ['device_id', 'device_name', 'ssid_prefix', 'location']
    ordering = ['device_name']
    readonly_fields = ['created_at', 'updated_at', 'last_heartbeat']
    
    fieldsets = (
        ('Device Information', {
            'fields': ('device_id', 'device_name', 'ssid_prefix', 'wifi_password', 'location', 'department', 'status')
        }),
        ('Network Information', {
            'fields': ('ip_address', 'last_heartbeat'),
            'classes': ('collapse',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

# ============================================================================
# NETWORK & FINGERPRINT ADMIN - Step 6: Advanced Features
# ============================================================================

@admin.register(NetworkSession)
class NetworkSessionAdmin(admin.ModelAdmin):
    list_display = ['course_assignment', 'esp32_device', 'date', 'start_time', 'end_time', 'is_active']
    list_filter = ['is_active', 'date', 'course_assignment__course__department']
    search_fields = ['course_assignment__course__code', 'esp32_device__device_name']
    ordering = ['-date', '-start_time']
    readonly_fields = ['created_at']
    
    fieldsets = (
        ('Session Information', {
            'fields': ('esp32_device', 'course_assignment', 'date', 'start_time', 'end_time', 'is_active')
        }),
        ('Timestamps', {
            'fields': ('created_at',),
            'classes': ('collapse',)
        }),
    )

@admin.register(ConnectedDevice)
class ConnectedDeviceAdmin(admin.ModelAdmin):
    list_display = ['mac_address', 'network_session', 'device_name', 'ip_address', 'is_connected', 'connected_at']
    list_filter = ['is_connected', 'network_session__course_assignment__course__department']
    search_fields = ['mac_address', 'device_name', 'network_session__course_assignment__course__code']
    ordering = ['-connected_at']
    readonly_fields = ['connected_at', 'disconnected_at']
    
    fieldsets = (
        ('Device Information', {
            'fields': ('network_session', 'mac_address', 'device_name', 'ip_address', 'is_connected')
        }),
        ('Connection Timestamps', {
            'fields': ('connected_at', 'disconnected_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(FingerprintEnrollment)
class FingerprintEnrollmentAdmin(admin.ModelAdmin):
    list_display = ['student', 'status', 'enrolled_at', 'enrolled_by', 'last_used']
    list_filter = ['status', 'enrolled_at', 'student__user_profile__department']
    search_fields = ['student__matric_number', 'student__user_profile__user__first_name']
    ordering = ['-enrolled_at']
    readonly_fields = ['enrolled_at', 'last_used']
    
    fieldsets = (
        ('Enrollment Information', {
            'fields': ('student', 'status', 'fingerprint_data', 'enrolled_by', 'notes')
        }),
        ('Timestamps', {
            'fields': ('enrolled_at', 'last_used'),
            'classes': ('collapse',)
        }),
    )

# ============================================================================
# SYSTEM ADMIN - Step 7: System Management
# ============================================================================

@admin.register(SystemLog)
class SystemLogAdmin(admin.ModelAdmin):
    list_display = ['timestamp', 'level', 'log_type', 'user', 'message_preview']
    list_filter = ['level', 'log_type', 'timestamp']
    search_fields = ['message', 'user__username']
    ordering = ['-timestamp']
    readonly_fields = ['timestamp']
    
    def message_preview(self, obj):
        return obj.message[:50] + '...' if len(obj.message) > 50 else obj.message
    message_preview.short_description = 'Message'
    
    fieldsets = (
        ('Log Information', {
            'fields': ('timestamp', 'level', 'log_type', 'user', 'message', 'details')
        }),
    )

@admin.register(SystemConfiguration)
class SystemConfigurationAdmin(admin.ModelAdmin):
    list_display = ['key', 'value_preview', 'is_editable', 'updated_at', 'updated_by']
    list_filter = ['is_editable', 'updated_at']
    search_fields = ['key', 'description']
    ordering = ['key']
    readonly_fields = ['updated_at', 'updated_by']
    
    def value_preview(self, obj):
        return obj.value[:50] + '...' if len(obj.value) > 50 else obj.value
    value_preview.short_description = 'Value'
    
    fieldsets = (
        ('Configuration', {
            'fields': ('key', 'value', 'description', 'is_editable')
        }),
        ('Timestamps', {
            'fields': ('updated_at', 'updated_by'),
            'classes': ('collapse',)
        }),
    )

# ============================================================================
# ADMIN SITE CUSTOMIZATION
# ============================================================================

admin.site.site_header = "🎓 Attendance System Administration"
admin.site.site_title = "Attendance System Admin"
admin.site.index_title = "Welcome to Attendance System Administration"

# Customize admin site ordering
admin.site.index_template = 'admin/custom_index.html'
