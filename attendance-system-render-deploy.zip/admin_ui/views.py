from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.models import User
from .forms import UserRegistrationForm, UserProfileForm, StudentRegistrationForm, LecturerRegistrationForm, LoginForm
from .models import UserProfile, Student, Lecturer, Course, CourseAssignment

def home_view(request):
    """Home page view"""
    return render(request, 'admin_ui/home.html')

def user_login(request):
    """User login view"""
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('admin_ui:dashboard')
            else:
                messages.error(request, 'Invalid username or password.')
    else:
        form = LoginForm()
    return render(request, 'admin_ui/login.html', {'form': form})

def user_logout(request):
    """User logout view"""
    logout(request)
    return redirect('admin_ui:home')

@login_required
def dashboard(request):
    """Main dashboard view"""
    try:
        profile = UserProfile.objects.get(user=request.user)
        if profile.user_type == 'student':
            return redirect('admin_ui:student_dashboard')
        elif profile.user_type == 'lecturer':
            return redirect('admin_ui:lecturer_dashboard')
        else:
            return redirect('admin_ui:admin_dashboard')
    except UserProfile.DoesNotExist:
        messages.error(request, 'User profile not found.')
        return redirect('admin_ui:home')

@login_required
def student_dashboard(request):
    """Student dashboard view"""
    try:
        student = Student.objects.get(user_profile__user=request.user)
        enrolled_courses = Course.objects.filter(
            courseenrollment__student=student,
            courseenrollment__is_active=True
        )
        context = {'student': student, 'enrolled_courses': enrolled_courses}
        return render(request, 'admin_ui/student_dashboard.html', context)
    except Student.DoesNotExist:
        messages.error(request, 'Student profile not found.')
        return redirect('admin_ui:dashboard')

@login_required
def lecturer_dashboard(request):
    """Lecturer dashboard view"""
    try:
        lecturer = Lecturer.objects.get(user_profile__user=request.user)
        assigned_courses = CourseAssignment.objects.filter(
            lecturer=lecturer,
            is_active=True
        )
        context = {'lecturer': lecturer, 'assigned_courses': assigned_courses}
        return render(request, 'admin_ui/lecturer_dashboard.html', context)
    except Lecturer.DoesNotExist:
        messages.error(request, 'Lecturer profile not found.')
        return redirect('admin_ui:dashboard')
