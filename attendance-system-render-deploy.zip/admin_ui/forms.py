from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import UserProfile, Student, Lecturer, Department, Course

class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)
    
    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2')

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['user_type', 'department', 'phone_number']

class StudentRegistrationForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['matric_number', 'level', 'admission_year']

class LecturerRegistrationForm(forms.ModelForm):
    class Meta:
        model = Lecturer
        fields = ['employee_id', 'qualification', 'specialization']

class LoginForm(forms.Form):
    username = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput)

class CSVUploadForm(forms.Form):
    csv_file = forms.FileField(label="Upload Student CSV")
    session = forms.CharField(max_length=20, required=False)
    level = forms.CharField(max_length=10, required=False)


